package com.aanchal.library.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="book_db")
public class BookDB {

	@Id
	private int refId;
    
	@Column
	private String title;
	
	@Column
	private String author;

	@Column
	private String PublishDate;
	
	@Column
	private double Price;
	
	@Column
	private String Status;
	
	@Column
	private int AvailableCount;
	
	public int getRefId() {
		return refId;
	}
	public void setRefId(int refId) {
		this.refId = refId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getPublishDate() {
		return PublishDate;
	}
	public void setPublishDate(String publishDate) {
		this.PublishDate = publishDate;
	}
	public double getPrice() {
		return Price;
	}
	public void setPrice(double price) {
		this.Price = price;
	}

	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		this.Status = status;
	}

	public int getAvailableCount() {
		return AvailableCount;
	}
	public void setAvailableCount(int availableCount) {
		this.AvailableCount = availableCount;
	}
	@Override
	public String toString() {
		return "Books [refId=" + refId + ", title=" + title + ", author=" + author + ", publishDate=" + PublishDate
				+ ", price=" + Price + ", status=" + Status + ", availableCount=" + AvailableCount + "]";
	}
	
	
	
}

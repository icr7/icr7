package com.aanchal.library.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="student_db")
public class StudentDB {

	@Id
	private int refid;

	@Column
	private String name;

	@Column
	private int bookref;

	
	public int getRefid() {
		return refid;
	}

	public void setRefid(int refid) {
		this.refid = refid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getBookref() {
		return bookref;
	}

	public void setBookref(int bookref) {
		this.bookref = bookref;
	}

	@Override
	public String toString() {
		return "Student [refid=" + refid + ", name=" + name + ", bookref=" + bookref + "]";
	}
	
	
		
}


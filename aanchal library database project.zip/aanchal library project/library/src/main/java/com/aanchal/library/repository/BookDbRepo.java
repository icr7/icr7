package com.aanchal.library.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.aanchal.library.model.BookDB;

public interface BookDbRepo extends JpaRepository<BookDB, Integer> {

}

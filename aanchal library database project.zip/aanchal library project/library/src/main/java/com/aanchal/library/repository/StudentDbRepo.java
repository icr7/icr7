package com.aanchal.library.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.aanchal.library.model.StudentDB;

public interface StudentDbRepo extends JpaRepository<StudentDB, Integer> {

}

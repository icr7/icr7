package com.aanchal.library.controller;

import java.io.IOException;
import javax.xml.bind.JAXBException;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.aanchal.library.model.Student;
import com.aanchal.library.model.Students;
import com.aanchal.library.repository.StudentRepository;

@RestController
@RequestMapping("/students")
public class StudentController {

	StudentRepository studentRepository = new StudentRepository();
	
	@GetMapping("/getAllStudents")
	public Students getAllStudents() throws JAXBException, IOException {
		return studentRepository.getAllStudents();
	}
	
	@GetMapping("/getStudentById/{id}")
	public Student getStudentById(@PathVariable String id) throws JAXBException, IOException {
		return studentRepository.getStudentById(id);
	}
	
	@PostMapping("/saveStudent")
	public void saveStudent(@RequestBody Student student) throws JAXBException, IOException {
		
		studentRepository.saveStudents(student);
	}


}

package com.aanchal.library.repository;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import com.aanchal.library.model.Book;
import com.aanchal.library.model.Books;

public class BookRepository {
	final File selectedFile = new File("C:\\Users\\ishwa\\aanchal\\aanchal library project\\library\\src\\main\\resources\\static\\books.xml");

	// Export
	public void saveBooks(Book book) throws IOException, JAXBException {

		Books books = getAllBooks();

		books.setBooks(book);

		JAXBContext context;
		BufferedWriter writer = null;
		writer = new BufferedWriter(new FileWriter(selectedFile));
		context = JAXBContext.newInstance(Books.class);
		Marshaller m = context.createMarshaller();
		m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		m.marshal(books, writer);
		writer.close();
	}

	// Import
	public Books getAllBooks() throws JAXBException {
		Books books = new Books();

		JAXBContext context = JAXBContext.newInstance(Books.class);
		Unmarshaller um = context.createUnmarshaller();
		books = (Books) um.unmarshal(selectedFile);

		return books;
	}

	public Book getBookById(int id) throws JAXBException {
		Books books = getAllBooks();
		for (int i = 0; i < books.getBooks().size(); i++) {
			if (books.getBooks().get(i).getRefId() == id) {
				return books.getBooks().get(i);
			}
		}

		return null;
	}

}
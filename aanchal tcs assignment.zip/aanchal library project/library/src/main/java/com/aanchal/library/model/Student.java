package com.aanchal.library.model;

public class Student {

	private String refid;

	private String name;

	private int bookref;

	public String getRefid() {
		return refid;
	}

	public void setRefid(String refid) {
		this.refid = refid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getBookref() {
		return bookref;
	}

	public void setBookref(int bookref) {
		this.bookref = bookref;
	}

	@Override
	public String toString() {
		return "Student [refid=" + refid + ", name=" + name + ", bookref=" + bookref + "]";
	}
	
	
		
}

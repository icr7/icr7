package com.aanchal.library.repository;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import com.aanchal.library.model.Student;
import com.aanchal.library.model.Students;

public class StudentRepository {
	final File selectedFile = new File("C:\\Users\\ishwa\\aanchal\\tcs project\\library\\src\\main\\resources\\static\\students.xml");

	
	public void saveStudents(Student student) throws IOException, JAXBException {

		Students students = getAllStudents();

		students.setStudents(student);

		JAXBContext context;
		BufferedWriter writer = null;
		writer = new BufferedWriter(new FileWriter(selectedFile));

		context = JAXBContext.newInstance(Students.class);
		Marshaller m = context.createMarshaller();
		m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		m.marshal(students, writer);
		writer.close();
	}


	public Students getAllStudents() throws JAXBException {
		Students students = new Students();
		JAXBContext context = JAXBContext.newInstance(Students.class);
		Unmarshaller um = context.createUnmarshaller();
		students = (Students) um.unmarshal(selectedFile);
		return students;
	}

	public Student getStudentById(String id) throws JAXBException {
		Students students = getAllStudents();
		for (int i = 0; i < students.getStudents().size(); i++) {
			if (students.getStudents().get(i).getRefid().equals(id)) {
				return students.getStudents().get(i);
			}
		}

		return null;
	}

}
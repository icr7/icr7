package com.aanchal.library.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "book")

@XmlAccessorType(XmlAccessType.FIELD)

public class Book {

	private int refId;

	private String title;
	
	private String author;

	private String PublishDate;
	
	private double Price;
	
	private String Status;
	
	private int AvailableCount;
	
	public int getRefId() {
		return refId;
	}
	public void setRefId(int refId) {
		this.refId = refId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getPublishDate() {
		return PublishDate;
	}
	public void setPublishDate(String publishDate) {
		this.PublishDate = publishDate;
	}
	public double getPrice() {
		return Price;
	}
	public void setPrice(double price) {
		this.Price = price;
	}

	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		this.Status = status;
	}

	public int getAvailableCount() {
		return AvailableCount;
	}
	public void setAvailableCount(int availableCount) {
		this.AvailableCount = availableCount;
	}
	@Override
	public String toString() {
		return "Books [refId=" + refId + ", title=" + title + ", author=" + author + ", publishDate=" + PublishDate
				+ ", price=" + Price + ", status=" + Status + ", availableCount=" + AvailableCount + "]";
	}
	
	
	
}

package com.aanchal.library.model;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
 
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "students")
public class Students {
 
    @XmlElement(name = "student", type = Student.class)
    private List<Student> students = new ArrayList<Student>();
     
    public Students() {}
 
    public Students(List<Student> student) {
        this.students = students;
    }
 
    public List<Student> getStudents() {
        return students;
    }
 
    public void setStudents(Student student) {
    	students.add(student);
    }   

}

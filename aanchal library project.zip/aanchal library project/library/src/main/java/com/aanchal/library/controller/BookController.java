package com.aanchal.library.controller;

import java.io.IOException;
import javax.xml.bind.JAXBException;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.aanchal.library.model.Book;
import com.aanchal.library.model.Books;
import com.aanchal.library.repository.BookRepository;

@RestController
@RequestMapping("/books")
public class BookController {

	BookRepository bookRepository = new BookRepository();
	
	@GetMapping("/getAllBooks")
	public Books getAllBooks() throws JAXBException, IOException {
	
		return bookRepository.getAllBooks();
	}
	
	@GetMapping("/getBookById/{id}")
	public Book getBookById(@PathVariable int id) throws JAXBException, IOException {
		return bookRepository.getBookById(id);
	}
	
	@PostMapping("/saveBook")
	public void saveBook(@RequestBody Book book) throws JAXBException, IOException {
		
		bookRepository.saveBooks(book);
	}

}
